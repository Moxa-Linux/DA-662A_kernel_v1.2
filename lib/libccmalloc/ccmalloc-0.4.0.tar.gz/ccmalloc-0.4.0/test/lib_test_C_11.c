#include <stdlib.h>

void * MALLOC(size_t n)
{
  return malloc(n);
}
