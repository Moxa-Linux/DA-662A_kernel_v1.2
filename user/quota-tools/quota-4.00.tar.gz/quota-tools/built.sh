#!/bin/sh


S_PREFIX_PATH="/home/work/spkg/binary/arm/quota-tools"
rm -r ${S_PREFIX_PATH}

export CC=/usr/local/arm-linux/bin/arm-mv5sft-linux-gnueabi-gcc
export CFLAGS=-I/usr/local/arm-linux/arm-mv5sft-linux-gnueabi/include
export CPP=/usr/local/arm-linux/bin/arm-mv5sft-linux-gnueabi-cpp
export CPPFLAGS=-I/usr/local/arm-linux/arm-mv5sft-linux-gnueabi/include
export LD=/usr/local/arm-linux/bin/arm-mv5sft-linux-gnueabi-ld
export LDFLAGS=-L/usr/local/arm-linux/arm-mv5sft-linux-gnueabi/lib
export AR=/usr/local/arm-linux/bin/arm-mv5sft-linux-gnueabi-ar
export AS=/usr/local/arm-linux/bin/arm-mv5sft-linux-gnueabi-as
export STRIP=/usr/local/arm-linux/bin/arm-mv5sft-linux-gnueabi-strip
export RANLIB=/usr/local/arm-linux/bin/arm-mv5sft-linux-gnueabi-ranlib


./configure   --build=x86_64 \
							--host=arm-mv5sft-linux-gnueabi \
							--prefix=${S_PREFIX_PATH}

#make
