#ifndef BYLABEL_H_
#define BYLABEL_H_
const char *get_device_name(const char *item);
#endif /* BYLABEL_H_ */
