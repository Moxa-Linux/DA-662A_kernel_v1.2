/*
 * WPA Supplicant
 * Copyright (c) 2003-2005, Jouni Malinen <jkmaline@cc.hut.fi>
 * Copyright (c) 2004-2005, Devicescape Software, Inc.
 * All Rights Reserved.
 */

#ifndef VERSION_H
#define VERSION_H

/* Version number from the open source version */
#define VERSION_STR "0.5.1"

/* Devicescape build number for SWC releases */
#define BUILD_STR " (developer snapshot)"

#endif /* VERSION_H */
