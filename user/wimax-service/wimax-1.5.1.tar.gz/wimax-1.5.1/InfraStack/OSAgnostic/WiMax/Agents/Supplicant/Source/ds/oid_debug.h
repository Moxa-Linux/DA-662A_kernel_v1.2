/*
 * WPA Supplicant - Debug helper for naming NDIS OIDs
 * Copyright (c) 2005, Devicescape Software, Inc.
 * All Rights Reserved.
 */

#ifndef OID_DEBUG_H
#define OID_DEBUG_H

const char * ndis_get_oid_name(UINT oid);

#endif /* OID_DEBUG_H */
