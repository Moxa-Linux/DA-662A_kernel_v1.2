/*
 * WPA Supplicant - Registry configuration functions for Win32
 * Copyright (c) 2005 Devicescape Software, Inc.
 * All Rights Reserved.
 */

#ifndef CONFIG_REGISTRY_H
#define CONFIG_REGISTRY_H

int wpa_reg_read_iface(char **confname, char **iface);

#endif /* CONFIG_REGISTRY_H */
