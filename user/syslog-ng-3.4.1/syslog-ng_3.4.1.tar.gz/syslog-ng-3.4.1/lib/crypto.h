#ifndef CRYPTO_H_INCLUDED
#define CRYPTO_H_INCLUDED

#include "syslog-ng.h"

#endif
