
/* Define if you have the sys_errlist[] array */
#undef HAVE_SYSERRLIST

