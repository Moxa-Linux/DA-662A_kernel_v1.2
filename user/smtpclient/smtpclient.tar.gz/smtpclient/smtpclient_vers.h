
extern char SMTPclient_Version[];
extern char SMTPclient_Hello[];
extern char SMTPclient_GNUVersion[];
extern char SMTPclient_WhatID[];
extern char SMTPclient_RCSIdentID[];
extern char SMTPclient_WebID[];
extern char SMTPclient_PlainID[];

