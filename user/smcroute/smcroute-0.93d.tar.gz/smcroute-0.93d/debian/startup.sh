#!/bin/sh
# This script is executed at startup by /etc/init.d/smcroute
#
# Add your calls to smcroute to setup your multicast routes here

