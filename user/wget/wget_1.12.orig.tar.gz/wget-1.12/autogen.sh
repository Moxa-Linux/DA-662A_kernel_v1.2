#!/bin/sh -x

exec autoreconf
