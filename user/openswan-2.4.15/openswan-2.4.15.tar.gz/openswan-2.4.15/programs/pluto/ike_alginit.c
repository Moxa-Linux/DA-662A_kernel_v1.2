extern int ike_alg_init(void);  int ike_alg_init(void) {
{
    // done in crypto.c
}
return 0;}
