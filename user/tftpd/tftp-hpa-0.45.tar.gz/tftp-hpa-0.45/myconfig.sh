#!/bin/sh
CC=xscale_be-gcc LD=xscale_be-ld CPP=xscale_be-cpp STRIP=xscale_be-strip AR=mxscaleb-ar RANLIB=mxscaleb-ranlib ./configure \
	--without-tcpwrappers \
	--host=arm-linux \
#	--without-remap \
	
