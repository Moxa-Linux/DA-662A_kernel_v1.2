#ifndef DHCPD_NETTEL_H
#define DHCPD_NETTEL_H

int commitChanges(void);
void config_exhausted(void);

#endif
