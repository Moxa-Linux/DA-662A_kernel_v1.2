/* Current version of ISC DHCP Distribution. */

#define DHCP_VERSION	"2.0pl5"
