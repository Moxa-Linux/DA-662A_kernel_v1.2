/* Enable debugging mode. */
#undef DEBUG_MODE

@BOTTOM@

/* Define to 'int' if <sys/socket.h> doesn't define. */
#undef socklen_t

/* Define to 0xffffffff if <netinet/in.h> doesn't define. */
#undef INADDR_NONE
