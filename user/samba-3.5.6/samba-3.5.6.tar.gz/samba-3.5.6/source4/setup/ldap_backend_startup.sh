#!/bin/sh
${SLAPD_COMMAND}
